#include <iostream>
using namespace std;

int main(){

    int m;
    int n;
    int kolom , baris;
    
   
    cout << "Isi Baris : ";
    cin >> baris;

    cout << "Isi Kolom : ";
    cin >> kolom;



    for (m = 1; m <= baris; m++)
    { for (n = 1; n <= 5; n++)
    {
        cout << "0" << "1";
    }
     cout << endl;
    }
}